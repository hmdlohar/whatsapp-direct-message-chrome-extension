# Chrome Web Store Listing

## Basic Info
- **Title**: WhatsApp Direct Message
- **Description (Short)**: Send WhatsApp messages to any number directly
- **Description (Extended)**: 
  Send WhatsApp messages directly to any phone number, even if not in your contacts. Works on web WhatsApp.
  
  Features:
  • Send messages to unknown numbers
  • Auto-formats phone numbers (adds country code)
  • History syncs across all your devices
  • Quick access to recent numbers
  • Detailed history with pagination

- **Category**: Productivity
- **Language**: English

## Screenshots Required
Place these in the `preview/` folder:

1. **screenshot-1.png** (1280x800) - Main popup showing phone input
2. **screenshot-2.png** (1280x800) - History dropdown visible
3. **screenshot-3.png** (1280x800) - Options page with history

## Promo Images (Optional)
- **Promo tile** (440x280)
- **Small promo tile** (230x180)

## Icon Requirements
- 128x128 PNG (already have: icon.png)

## Privacy Policy
Required if extension accesses user data. Since we use chrome.storage.sync for history, create a privacy policy:

```
Privacy Policy

WhatsApp Direct Message extension stores your phone number history and preferences locally using Chrome's sync storage. This data is synced across your Chrome instances for your convenience.

We do not collect, transmit, or share any personal information with third parties. The phone numbers you enter are only used to generate WhatsApp message links.

For any privacy concerns, please contact the developer.
```

## Publishing Steps
1. Go to Chrome Web Store Developer Dashboard
2. Upload the extension (zip all files except preview folder)
3. Fill in store listing details
4. Submit for review

## Files Structure
```
wa-direct/
├── icon.png              (128x128)
├── manifest.json
├── popup.html
├── popup.js
├── options.html
├── options.js
├── preview/
│   ├── screenshot-1.png
│   ├── screenshot-2.png
│   └── screenshot-3.png
└── STORE_LISTING.md
```
